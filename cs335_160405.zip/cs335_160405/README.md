# CS335: Compiler Design

## Assignment 1

### To run the lexer

* Type `python src/lexer.py --cfg="tests/cfg/configX.txt tests/input/inputY.go" --output="tests/output/some-file.html"`

* Make sure that the value to cfg argument are in double quotes so that the input filename is not skipped.

* There are 3 config files and 5 input files.