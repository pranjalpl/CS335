// The typechecking and stuff
// 

package maie;

import "fmt";

func test(a, b int_t) int_t {
	return;
};

func notmain() {
	var i int_t =3;
	var j int_t = test(1,2);
	i  += j;
};

func noatmain() {
	var i int_t = 1;
	var j int_t = test(1,2);
	const a int_t = 10.01;
	i  += j;
};

func main() {
	var i int_t = 1 + (1 + test(i,i));
	var j float_t = 2 + test(1,j);
	var k float_t = notmain();
	// var a string_t = "asdf";
	// a = 1;
	// if i == 1 {
	// 	return 2;
	// };
	// print i;
	// return 1 + 2;
};


