// playing around with structs

package math;
type Node struct{
	i int_t;
	j int_t;
};

func temp(a type Node, b type Node) int_t {
	return a.i + a.j;
};
func main() {
	var n type Node;
	var m type Node;
	temp(n, m);
};
