// A normal level 0 test case
package maie;

import "fmt";

func test(a, b int_t) {
	return;
};

func notmain() {
	var i int_t =3;
	var j int_t = 5;
	i  += j;
};
func noatmain() {
	var i int_t = 1;
	var j int_t = 5;
	const a float_t = 10.01;
	i  += j;
};
func main() {
	var a float_t = 3.1254;
	return 1;
};


