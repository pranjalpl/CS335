// Type checking on structs

package mai;

import "fmt";
type Node struct{
	i int_t;
	j int_t;
};

func main() {
	var a int_t = 3;
	var b = a << 2;
	var m type Node;
	print(a);
	print(b);
	m.ia = 1.5;
};
