# Milestone - 3

## To Run the Parser

* `python src/parser.py --input="tests/input/test{no}.html"`
where no is from 1 to 10

## References

* [GOtham](https://github.com/pkhrag/cs335)
* [The Go Programming Language Specification](https://golang.org/ref/spec#Notation)