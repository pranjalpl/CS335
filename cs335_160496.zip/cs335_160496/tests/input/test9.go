package mai;
import "fmt";
func main() {
	
	var h [1] int_t;
	var k [1] int_t;
	var t [2] rune_t;
	scan(h[0]);
	scan(k[0]);
	//( = h+k);
	print(&h[0]);
	return;
};
