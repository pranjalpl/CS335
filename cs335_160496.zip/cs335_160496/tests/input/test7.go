package mai;

import "fmt";

func main() {
	var a int_t = 3;
	var b = a << 2;
	print(a);
	print(b);
};
