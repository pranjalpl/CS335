package math;
import "fmt";

func main() {

	var i int_t = 5;
	for j:=0;j<i;j++
	{
		print(j);
	};
	return;
};
