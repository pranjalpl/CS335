package maie;

import "fmt";

func test(a int_t,b int_t) {
	return b;
};

func notmain() {
	var i int_t =3;
	var j int_t = 3;
	//maie.printIn(i);
};
func noatmain() {
	var i,j int_t;
	print("d");
	const a int_t = 10;
};
func main() {
	return 1;
};


