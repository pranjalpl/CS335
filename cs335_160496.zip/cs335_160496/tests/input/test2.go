package mai;
import "fmt";

func main() {

	var j[5] int_t;
	j[3]= 4;
	var k *int_t = j+8;
	print(k[1]);
	return;
};
