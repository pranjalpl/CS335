# CS335: Compiler Design

## Milestone 2

### To Run the Parser and Create the CSV and IR output files

* `python src/parser.py --input=tests/input/testno.html`

## References

* [GOtham](https://github.com/pkhrag/cs335)
* [The Go Programming Language Specification](https://golang.org/ref/spec#Notation)